


PORT = 8000

# Clients Namespaces
HARDWARE_NAMESPACE = '/'
WEB_NAMESPACE = '/web'
MOBILE_NAMESPACE = '/mobile'
