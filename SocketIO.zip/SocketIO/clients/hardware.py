from sys import path_hooks
import socketio
from Library.api_response import ApiResponse
from rest_framework import status

from Apps.Hardware.serializers.models_serializers import SensorValueSerializer, SensorSerializer, ActuatorSerializer, ActuatorActionsSerializer
from Apps.Hardware.serializers.requests_serializers import StoreSensorValuesSerializer, TakeActionSerializer



from Library.api_response import ApiResponse
from SocketIO.socketio_server_settings import HARDWARE_NAMESPACE, WEB_NAMESPACE, MOBILE_NAMESPACE

from FuzzyLogic.controllers.PHFuzzyLogic import PHFuzzyLogic
from FuzzyLogic.controllers.TempFuzzyLogic import TempFuzzyLogic

from FuzzyLogic.control_system import implement_controller 

from Apps.Hardware.hardware_library.sensors import PHSensor , TempratureSensor
from Apps.Hardware.hardware_library.actuators import AlkalinePumpActuator,PHPumpActuator,FanActuator


temp_fuzzy_controller = implement_controller(TempFuzzyLogic())
ph_fuzzy_controller   = implement_controller(PHFuzzyLogic())

# {
#             "status_code": 200,
#             "sensors": [
#                 {
#                     "value": "10",
#                     "created_at": "2022-03-10T20:17:39.027452Z",
#                     "sensor": 1
#                 },
#                 {
#                     "value": "10",
#                     "created_at": "2022-03-10T20:17:39.035355Z",
#                     "sensor": 2
#                 }
#             ]
#         }

# ------------------------------------------------------ Hardware Client
class HardwareNamespace(socketio.Namespace):

    def on_connect(self, sid, message):

        print("Hardware Connected Successfully")

        clients_response = ApiResponse()

        response = clients_response.set_status_code(200).set_data('message', 'Hardware connected successfully').get()

        self.enter_room(sid, namespace=HARDWARE_NAMESPACE,  room="myGreenhouse")
        
        self.emit('hardware_connection', response, namespace=WEB_NAMESPACE,  room="myGreenhouse")
        self.emit('hardware_connection', response, namespace=MOBILE_NAMESPACE, room="myGreenhouse")


    def on_sensors_values(self, sid, data):
        print("Hardware Sent Sensor Values Successfully")

        api_response = ApiResponse()

        serializer = StoreSensorValuesSerializer(data=data)

        if not serializer.is_valid():
            print(serializer.errors)
            response = api_response.set_status_code(status.HTTP_400_BAD_REQUEST).set_data("errors", serializer.errors).get()
            self.emit('send_sensor_values_status', response, namespace=HARDWARE_NAMESPACE, room="myGreenhouse")

        else:
            print("Successfully ya mega")
            print(serializer.save())
            sensor_values = serializer.save()
            api_response.set_status_code(status.HTTP_200_OK).set_data("sensors", SensorValueSerializer(sensor_values, many=True).data)

            response = api_response.get()
            
            
            # ph_value = serializer.get_sensor_value(PHSensor.ID)
            # temp_value = serializer.get_sensor_value(TempratureSensor.ID)
            # if ph_value:
            #     ph_fuzzy_controller.set_ph_value(ph_value)
            #     ph_fuzzy_controller.set_water_level_value(ph_value)

            
        # response = "Sensor Values from NodeMCU"
        self.emit('sensors_values', response, namespace=WEB_NAMESPACE,  room='myGreenhouse')
        self.emit('sensors_values', response, namespace=MOBILE_NAMESPACE,  room='myGreenhouse')

    def on_disconnect(self, sid):
        print("Hardware Disconnected")

        api_response = ApiResponse()

        response = api_response.set_status_code(status.HTTP_501_NOT_IMPLEMENTED).set_data(
            'message', 'Hardware disconnected').get()

        self.emit('hardware_connection', response, namespace=WEB_NAMESPACE,  room='myGreenhouse')
        self.emit('hardware_connection', response, namespace=MOBILE_NAMESPACE,  room='myGreenhouse')


# print(
#     f"Execution time is: {timeit.timeit( stmt = HardwareNamespace.on_sensors_values, number = 1)}")
